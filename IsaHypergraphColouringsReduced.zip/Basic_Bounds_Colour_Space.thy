(* Theory: Basic_Bounds_Colour_Space.thy
   Author: Chelsea Edmonds
*)

section \<open>Basic Probabilistic Method Application\<close>
text \<open>This section establishes step (1) of the basic framework for incidence set systems, 
as well as some basic bounds on hypergraph colourings \<close>
theory Basic_Bounds_Colour_Space imports "Lovasz_Local.Basic_Method" Basic_Bounds_Setup
begin

text \<open>A uniform vertex colouring space \<close>
locale vertex_colour_space = fin_hypergraph_nt +
  fixes n :: nat (*Number of colours *)
  assumes n_lt_order: "n \<le> horder"
  assumes n_not_zero: "n \<noteq> 0"


sublocale vertex_colour_space \<subseteq> vertex_prop_space \<V> E "{0..<n}"
  rewrites "\<Omega>U = \<C>\<^sup>n" 
proof -
  have "{0..<n} \<noteq> {}" using n_not_zero by simp
  then interpret vertex_prop_space \<V> E "{0..<n}"
    by (unfold_locales) (simp_all)
  show "vertex_prop_space \<V> E {0..<n}" by (unfold_locales)
  show "\<Omega>U = \<C>\<^sup>n"
    using \<Omega>_def all_n_vertex_colourings_alt by auto
qed

text \<open>This probability space contains several useful lemmas on basic vertex colouring probabilities
(and monochromatic edges), which are facts that are typically either not proven, or have very short
proofs on paper \<close>
context vertex_colour_space
begin


lemma colour_functions_event: "(\<lambda> c. {f \<in> \<C>\<^sup>n . mono_edge_col f e c}) ` {0..<n} \<subseteq> events"
  using sets_eq by blast

lemma prob_edge_colour: 
  assumes "e \<in># E" "c \<in> {0..<n}"
  shows "prob {f \<in> \<C>\<^sup>n . mono_edge_col f e c} = 1/(n powi (card e))"
proof -
  have "card {0..<n} = n" by simp
  moreover have "\<C>\<^sup>n = \<V> \<rightarrow>\<^sub>E {0..<n}" using all_n_vertex_colourings_alt by blast
  moreover have "{0..<n} \<noteq> {}" using n_not_zero by simp
  ultimately show ?thesis using prob_uniform_ex_fun_space[of \<V> _ "{0..<n}" e] n_not_zero 
      finite_sets wellformed assms by (simp add: MU_def V_nempty mono_edge_col_def)
qed

lemma prob_monochromatic_edge_inv: 
  assumes "e \<in># E"
  shows "prob{f \<in> \<C>\<^sup>n . mono_edge f e} = 1/(n powi (int (card e) - 1))"
proof -
  have "finite {0..<n}"by auto
  then have "prob {f \<in> \<C>\<^sup>n . mono_edge f e} = (\<Sum>c \<in> {0..<n} . prob {f \<in> \<C>\<^sup>n . mono_edge_col f e c})"
    using finite_measure_finite_Union[of "{0..<n}" "(\<lambda> c . {f \<in> \<C>\<^sup>n .  mono_edge_col f e c})" ] 
      disjoint_family_on_colourings colour_functions_event mono_edge_set_union assms by auto
  also have "... = n/(n powi (int (card e)))" using prob_edge_colour assms by simp
  also have "... = n/(n* (n powi ((int (card e)) - 1)))" using n_not_zero 
      power_int_commutes power_int_minus_mult by (metis of_nat_0_eq_iff) 
  finally show ?thesis using n_not_zero by simp 
qed

lemma prob_monochromatic_edge: 
  assumes "e \<in># E"
  shows "prob{f \<in> \<C>\<^sup>n . mono_edge f e} = n powi (1 - int (card e))"
  using prob_monochromatic_edge_inv assms n_not_zero by (simp add: power_int_diff) 

end

(* Note: These are not needed for basic method - just other useful results
subsection \<open>More Hypergraph Colouring Results \<close>

context fin_hypergraph_nt
begin

lemma not_proper_colouring_edge_mono: "{f \<in> \<C>\<^sup>n . \<not> is_proper_colouring f n} = (\<Union>e \<in> (set_mset E). {f \<in> \<C>\<^sup>n . mono_edge f e})"
proof -
  have "{f \<in> \<C>\<^sup>n . \<not> is_proper_colouring f n} = {f \<in> \<C>\<^sup>n . \<exists> e \<in> set_mset E . mono_edge f e}"
    using ex_monochomatic_not_colouring no_monochomatic_is_colouring 
    by (metis (mono_tags, lifting) all_n_vertex_colourings_alt)
  then show ?thesis using Union_exists by simp
qed

lemma proper_colouring_edge_mono: "{f \<in> \<C>\<^sup>n . is_proper_colouring f n} = (\<Inter>e \<in> (set_mset E). {f \<in> \<C>\<^sup>n . \<not> mono_edge f e})"
proof -
  have "{f \<in> \<C>\<^sup>n . is_proper_colouring f n} = {f \<in> \<C>\<^sup>n . \<forall> e \<in> set_mset E . \<not> mono_edge f e}"
    using is_proper_colouring_alt2 all_n_vertex_colourings_alt by auto
  moreover have "set_mset E \<noteq> {}" using E_nempty by simp
  ultimately show ?thesis using Inter_forall by auto
qed

lemma proper_colouring_edge_mono_compl: "{f \<in> \<C>\<^sup>n . is_proper_colouring f n} = (\<Inter>e \<in> (set_mset E). \<C>\<^sup>n - {f \<in> \<C>\<^sup>n . mono_edge f e})"
  using proper_colouring_edge_mono by auto

end

*)

end
