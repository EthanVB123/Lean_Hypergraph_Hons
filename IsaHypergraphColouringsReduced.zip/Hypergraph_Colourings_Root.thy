theory Hypergraph_Colourings_Root 
  imports
    Hypergraph_Colourings
    Basic_Bounds_Setup
    Basic_Bounds_Colour_Space
    Basic_Bounds_Application
begin
end