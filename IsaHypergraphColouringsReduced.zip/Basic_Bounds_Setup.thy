(* Theory: Basic_Bounds_Setup.thy
   Author: Chelsea Edmonds
*)

section \<open>Basic Probabilistic Method Application\<close>
text \<open>This section establishes step (1) of the basic framework for incidence set systems, 
as well as some basic bounds on hypergraph colourings \<close>
theory Basic_Bounds_Setup imports "Lovasz_Local.Basic_Method" Hypergraph_Colourings
begin

subsection \<open>Probability Spaces for Incidence Set Systems \<close>
text \<open>This is effectively step (1) of the formal framework for probabilistic method. Unlike stages (3) 
and (4), which were formalised in the Lovasz\_Local\_Lemma AFP entry, this stage required a 
formalisation of incidence set systems as well as the background probability space locales \<close>

text \<open>A basic probability space for a point measure on a non-trivial structure \<close>
locale vertex_fn_space = fin_hypersystem_vne +
  fixes F :: "'a set \<Rightarrow> 'b set"
  fixes p :: "'b \<Rightarrow> real"
  assumes ne: "F \<V> \<noteq> {}"
  assumes fin: "finite (F \<V>)"
  assumes pgte0: "\<And> fv . fv \<in> F \<V> \<Longrightarrow> p fv \<ge> 0"
  assumes sump: "(\<Sum>x \<in> (F \<V>) . p x) = 1"
begin

definition "\<Omega> \<equiv> F \<V>" (* model space *)

lemma fin_\<Omega>: "finite \<Omega>"
  unfolding \<Omega>_def using fin by auto

lemma ne_\<Omega>: "\<Omega> \<noteq> {}"
  unfolding \<Omega>_def using ne by simp

definition "M = point_measure \<Omega> p"

lemma space_eq: "space M = \<Omega>"
  unfolding M_def \<Omega>_def by (simp add: space_point_measure)

lemma sets_eq: "sets M =  Pow (\<Omega>)"
  unfolding M_def by (simp add: sets_point_measure)

lemma finite_event: "A \<subseteq> \<Omega> \<Longrightarrow> finite A"
  by (simp add: finite_subset fin_\<Omega>)

lemma emeasure_eq: "emeasure M A = (if (A \<subseteq> \<Omega>) then (\<Sum>a\<in>A. p a) else 0)"
proof (cases "A \<subseteq> \<Omega>")
  case True
  then have "finite A" using finite_event by auto
  moreover have "ennreal (sum p A) = (\<Sum>a\<in>A. ennreal (p a))" 
    using sum_ennreal pgte0 True by (simp add: subset_iff \<Omega>_def) 
  ultimately have "emeasure M A = (\<Sum>a\<in>A. p a)" 
    using emeasure_point_measure_finite2[of A \<Omega> p] M_def
    using True by presburger 
  then show ?thesis using True by auto
next
  case False
  then show ?thesis using emeasure_notin_sets sets_eq by auto
qed

lemma integrable_M[intro, simp]: "integrable M (f::_ \<Rightarrow> real)"
  using fin_\<Omega> by (simp add: integrable_point_measure_finite M_def)

lemma borel_measurable_M[measurable]: "f \<in> borel_measurable M"
  unfolding M_def by simp

lemma prob_space_M: "prob_space M"
  unfolding M_def using fin_\<Omega> ne_\<Omega> pgte0 sump \<Omega>_def
  by (intro prob_space_point_measure) (simp_all)

end

sublocale vertex_fn_space \<subseteq> prob_space M
  using prob_space_M .

text \<open>A uniform variation of the space \<close>
locale vertex_fn_space_uniform = fin_hypersystem_vne +
  fixes F :: "'a set \<Rightarrow> 'b set"
  assumes ne: "F \<V> \<noteq> {}"
  assumes fin: "finite (F \<V>)"
begin

definition "\<Omega>U \<equiv> F \<V>"

definition "MU \<equiv> uniform_count_measure \<Omega>U"

end

sublocale vertex_fn_space_uniform \<subseteq> vertex_fn_space \<V> E F "(\<lambda>x. 1 / card \<Omega>U)"
  rewrites  "\<Omega> = \<Omega>U" and "M = MU"
proof (unfold_locales )
  show 1: "F \<V> \<noteq> {}" and 2: "finite (F \<V>)" by (simp_all add: fin ne)
  show 3: "\<And>fv. fv \<in> F \<V> \<Longrightarrow> 0 \<le> 1 / real (card (\<Omega>U))" by auto
  show 4: "(\<Sum>x\<in>F \<V>. 1 / real (card \<Omega>U)) = 1"
    using sum_constant ne fin \<Omega>U_def by auto
  interpret vf: vertex_fn_space \<V> E F "(\<lambda>x. 1 / card (\<Omega>U))"
    using 1 2 3 4 by (unfold_locales)
  show "vf.\<Omega> = \<Omega>U" unfolding vf.\<Omega>_def \<Omega>U_def by simp
  show "vf.M = MU"  unfolding vf.M_def vf.\<Omega>_def MU_def uniform_count_measure_def using \<Omega>U_def by auto
qed

context vertex_fn_space_uniform
begin

lemma emeasure_eq: "emeasure MU A = (if (A \<subseteq> \<Omega>U) then ((card A)/card (\<Omega>U)) else 0)"
  using fin_\<Omega> MU_def emeasure_uniform_count_measure[of "\<Omega>U" "A"]
    sets_uniform_count_measure emeasure_notin_sets Pow_iff ennreal_0 by (metis (full_types))

lemma measure_eq_valid: "A \<in> events \<Longrightarrow> measure MU A = (card A)/card (\<Omega>U)"
  using sets_eq by (simp add: MU_def \<Omega>U_def fin measure_uniform_count_measure) 

lemma expectation_eq:
  shows "expectation f = (\<Sum> x \<in> \<Omega>U. f x) / card \<Omega>U"
proof-
  have "(\<And>a. a \<in> \<Omega>U \<Longrightarrow> 0 \<le> 1 / real (card \<Omega>U))"
    using fin_\<Omega> ne_\<Omega> by auto
  moreover have "\<And> a. a\<in>\<Omega>U \<Longrightarrow> (1 / real (card \<Omega>U)) *\<^sub>R f a = 1 / (card \<Omega>U) * f a"
    using real_scaleR_def by simp
  ultimately have "expectation f = (\<Sum> x \<in> \<Omega>U. f x * (1 / (card \<Omega>U)))" 
    using uniform_count_measure_def[of \<Omega>U] lebesgue_integral_point_measure_finite[of \<Omega>U "(\<lambda> x. 1 / card \<Omega>U)" "f"] 
      MU_def fin_\<Omega> by auto
  then show ?thesis using sum_distrib_right[symmetric, of f "1 / (card \<Omega>U)" \<Omega>U] by auto
qed

end

text \<open>A probability space over the full vertex set \<close>
locale vertex_space = fin_hypersystem_vne +
  fixes p :: "'a \<Rightarrow> real"
  assumes pgte0: "\<And> fv . fv \<in> \<V> \<Longrightarrow> p fv \<ge> 0"
  assumes sump: "(\<Sum>x \<in> (\<V>) . p x) = 1"


sublocale vertex_space \<subseteq> vertex_fn_space \<V> E "\<lambda> i . i" p
  rewrites "\<Omega> = \<V>"
proof (unfold_locales)
  interpret vertex_fn_space \<V> E "\<lambda> i . i" p
    by unfold_locales (simp_all add: pgte0 sump V_nempty finite_sets)
  show "\<Omega> = \<V>"
    using \<Omega>_def by simp
qed (simp_all add: pgte0 sump V_nempty finite_sets)

text \<open>A uniform variation of the probability space over the vertex set \<close>
locale vertex_space_uniform = fin_hypersystem_vne

sublocale vertex_space_uniform \<subseteq> vertex_fn_space_uniform \<V> E "\<lambda> i . i"
  rewrites "\<Omega>U = \<V>"
proof (unfold_locales)
 interpret vertex_fn_space_uniform \<V> E "\<lambda> i . i"
   by unfold_locales (simp_all add: V_nempty finite_sets)
  show "\<Omega>U = \<V>" unfolding \<Omega>U_def by simp
qed (simp_all add: V_nempty finite_sets)

text \<open>A uniform probability space over a vertex subset \<close>
locale vertex_ss_space_uniform = fin_hypersystem_vne + 
  fixes VS 
  assumes vs_ss: "VS \<subseteq> \<V>"
  assumes ne_vs: "VS \<noteq> {}"
begin

lemma finite_vs: "finite VS"
  using vs_ss finite_subset finite_sets by auto

end

sublocale vertex_ss_space_uniform \<subseteq> vertex_fn_space_uniform \<V> E "\<lambda> i. VS"
  rewrites "\<Omega> = VS" 
proof (unfold_locales)
  interpret vertex_fn_space_uniform \<V> E "\<lambda> i . VS" 
    by unfold_locales (simp_all add: ne_vs finite_vs)
  show "\<Omega> = VS"
    using \<Omega>_def by simp
qed (simp_all add: ne_vs finite_vs)

text \<open>A non-uniform prob space over a vertex subset \<close>
locale vertex_ss_space = fin_hypersystem_vne +
  fixes VS
  assumes vs_ss: "VS \<subseteq> \<V>"
  assumes ne_vs: "VS \<noteq> {}"
  fixes p :: "'a \<Rightarrow> real"
  assumes pgte0: "\<And> fv . fv \<in> VS \<Longrightarrow> p fv \<ge> 0"
  assumes sump: "(\<Sum>x \<in> (VS) . p x) = 1"
begin

lemma finite_vs: "finite VS"
  using vs_ss finite_subset finite_sets by auto

end

sublocale vertex_ss_space \<subseteq> vertex_fn_space \<V> E "\<lambda> i . VS" p
  rewrites "\<Omega> = VS"
proof (unfold_locales)
  interpret vertex_fn_space \<V> E "\<lambda> i . VS" p
    by unfold_locales (simp_all add: pgte0 sump ne_vs finite_vs)
  show "\<Omega> = VS"
    using \<Omega>_def by simp
qed (simp_all add: pgte0 sump ne_vs finite_vs)

text \<open>A uniform probability space over a property on the vertex set \<close>
locale vertex_prop_space = fin_hypersystem_vne + 
  fixes P :: "'b set" (* property *)
  assumes finP: "finite P"
  assumes nempty_P: "P \<noteq> {}"

sublocale vertex_prop_space \<subseteq> vertex_fn_space_uniform \<V> E "\<lambda> V. V \<rightarrow>\<^sub>E P"
rewrites "\<Omega>U = \<V> \<rightarrow>\<^sub>E P" 
proof -
  interpret vertex_fn_space_uniform \<V> E "\<lambda> V. V \<rightarrow>\<^sub>E P"
  proof (unfold_locales)
    show "\<V> \<rightarrow>\<^sub>E P \<noteq> {}" using finP V_nempty PiE_eq_empty_iff nempty_P by meson
    show "finite (\<V> \<rightarrow>\<^sub>E P)" using finP finite_PiE finite_sets by meson
  qed 
  show "vertex_fn_space_uniform \<V> E (\<lambda>V. V \<rightarrow>\<^sub>E P)" by unfold_locales
  show "\<Omega>U = \<V> \<rightarrow>\<^sub>E P "unfolding \<Omega>U_def by simp
qed

context vertex_prop_space
begin

lemma prob_uniform_vertex_subset: 
  assumes "b \<in> P"
  assumes "d \<subseteq> \<V>"
  shows "prob  {f \<in> \<Omega> . (\<forall> v \<in> d .f v = b)} = 1/((card P) powi (card d))"
  using finP nempty_P V_nempty finite_sets MU_def \<Omega>U_def
  by (simp add: assms(1) assms(2) prob_uniform_ex_fun_space) 

lemma prob_uniform_vertex: 
  assumes "b \<in> P"
  assumes "v \<in> \<V>"
  shows "prob  {f \<in> \<Omega>U . f v = b} = 1/(card P)"
proof -
  have "prob {f \<in> \<Omega>U . f v = b} = card {f \<in> \<Omega>U . f v = b}/card \<Omega>U"
    using measure_eq_valid sets_eq by auto
  then show ?thesis 
    using card_PiE_val_indiv_eq[of "\<V>" b P v] \<Omega>_def finite_sets finP nempty_P assms by auto
qed

end

end
