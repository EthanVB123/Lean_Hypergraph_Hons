(* Theory: Basic_Bounds_Application.thy
   Author: Chelsea Edmonds
*)

section \<open>Basic Probabilistic Method Application\<close>
text \<open>This section establishes step (1) of the basic framework for incidence set systems, 
as well as some basic bounds on hypergraph colourings \<close>
theory Basic_Bounds_Application imports "Lovasz_Local.Basic_Method" Basic_Bounds_Colour_Space
begin

subsection \<open>The Basic Application \<close>
text \<open>The comments below show the basic framework steps \<close>

context fin_kuniform_hypergraph_nt
begin
proposition erdos_propertyB:  
  assumes "size E < (2^(k - 1))"
  assumes "k > 0"
  shows "has_property_B"
proof -
  \<comment> \<open>(1) Set up the probability space: "Colour V randomly with two colours" \<close>
  interpret P: vertex_colour_space \<V> E 2 
    by unfold_locales (auto simp add: order_ge_two)
  \<comment> \<open>(2) define the event to avoid - monochromatic edges \<close>
  define A where "A \<equiv>(\<lambda> e. {f \<in> \<C>\<^sup>2 . mono_edge f e})"
  \<comment> \<open>(3) Calculation 2: Have Pr (of Ae for any e) \le Sum over e (Pr (A e)) < 1 \<close>
  have "(\<Sum>e \<in> set_mset E. P.prob (A e)) < 1"
  proof -
    have "2 powi (int k - 1) = real (2 ^ (k - 1))"
      by (simp add: \<open>k > 0\<close> power_int_def)
    then
    have "card (set_mset E) < 2 powi (int k - 1)" 
      using card_size_set_mset[of E] assms by linarith
    then have "(\<Sum>e \<in> (set_mset E). P.prob (A e)) < 2 powi (int k - 1) * 2 powi (1 - int k)"
      unfolding A_def using P.prob_monochromatic_edge uniform assms(1) by simp
    moreover have "((2 :: real) powi ((int k) - 1)) * (2 powi (1 - (int k))) = 1" 
      using power_int_add[of 2 "int k - 1" "1- int k"] by force 
    ultimately show ?thesis using power_int_add[of 2 "int k - 1" "1- int k"] by simp
  qed
  moreover have "A ` (set_mset E) \<subseteq> P.events" unfolding A_def P.sets_eq by blast
  \<comment> \<open>(4) obtain a colouring avoiding bad events \<close>
  ultimately obtain f where "f \<in> \<C>\<^sup>2" and "f \<notin> \<Union>(A `(set_mset E))" 
    using P.Union_bound_obtain_fun[of "set_mset E" A] finite_set_mset P.space_eq by auto 
  thus ?thesis using event_is_proper_colouring A_def is_n_colourable_def by auto 
qed

end

corollary erdos_propertyB_min: 
  fixes z :: "'a itself"
  assumes "n > 0"
  shows "(min_edges_colouring n z) \<ge> 2^(n - 1)"      
proof (rule ccontr)
  assume "\<not> 2 ^ (n - 1) \<le> min_edges_colouring n z"
  then have "min_edges_colouring n z < 2^(n - 1)" by simp
  then obtain h :: "'a hyp_graph" where hin: " h \<in> not_col_n_uni_hyps n" and 
    "enat (size (hyp_edges h)) < 2^(n-1)"
    using obtains_min_edge_colouring by blast 
  then have lt: " size (hyp_edges h) < 2^(n -1)"
    by (metis of_nat_eq_enat of_nat_less_imp_less of_nat_numeral of_nat_power)  
  then interpret kuf: fin_kuniform_hypergraph_nt "(hyp_verts h)" "hyp_edges h" n 
    using not_col_n_uni_hyps_def hin by auto 
  have "kuf.has_property_B" using kuf.erdos_propertyB lt assms by simp
  then show False using hin not_col_n_uni_hyps_def by auto 
qed

end
